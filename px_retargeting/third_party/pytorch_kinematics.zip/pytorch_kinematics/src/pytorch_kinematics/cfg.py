import os

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
TEST_DIR = os.path.join(ROOT_DIR, 'tests')
