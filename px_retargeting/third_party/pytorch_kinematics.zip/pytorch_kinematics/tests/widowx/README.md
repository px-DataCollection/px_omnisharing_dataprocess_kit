# WidowX 250 S Robot Description (URDF)

The robot model here is based on the real2sim project: https://github.com/simpler-env/SimplerEnv


